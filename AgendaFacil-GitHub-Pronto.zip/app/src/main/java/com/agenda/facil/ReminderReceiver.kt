package com.agenda.facil
import android.app.*
import android.content.*
import android.os.Build
class ReminderReceiver:BroadcastReceiver(){override fun onReceive(c:Context,i:Intent){val ch="agenda_lembretes";val nm=c.getSystemService(NotificationManager::class.java);if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(NotificationChannel(ch,"Lembretes",NotificationManager.IMPORTANCE_HIGH).apply{setSound(android.provider.Settings.System.DEFAULT_NOTIFICATION_URI,null)});val n=Notification.Builder(c,ch).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("🔔 Lembrete de compromisso").setContentText("Amanhã: ${i.getStringExtra("name")}").setAutoCancel(true).build();nm.notify((System.currentTimeMillis()%100000).toInt(),n)}}
