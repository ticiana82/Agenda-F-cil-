package com.agenda.facil

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.CalendarContract
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val req=42
    override fun onCreate(b: Bundle?) { super.onCreate(b); build(); requestPermissionsIfNeeded() }
    private fun requestPermissionsIfNeeded(){ val p=mutableListOf<String>(); if(android.os.Build.VERSION.SDK_INT>=33)p+=Manifest.permission.POST_NOTIFICATIONS; p+=Manifest.permission.READ_CALENDAR; p+=Manifest.permission.WRITE_CALENDAR; if(p.any{checkSelfPermission(it)!=PackageManager.PERMISSION_GRANTED}) requestPermissions(p.toTypedArray(),req) }
    private fun build(){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(32,48,32,32)}
        val title=TextView(this).apply{text="Agenda Fácil";textSize=30f;setPadding(0,0,0,12)}
        val sub=TextView(this).apply{text="Seus compromissos, sem complicação";textSize=16f;setPadding(0,0,0,28)}
        val add=Button(this).apply{text="＋  NOVO COMPROMISSO";setOnClickListener{newEvent()}}
        val google=Button(this).apply{text="Abrir Google Agenda";setOnClickListener{startActivity(Intent(Intent.ACTION_VIEW).setData(android.net.Uri.parse("content://com.android.calendar/time/")))}}
        val info=TextView(this).apply{text="\n🔔 Todo compromisso criado aqui recebe um lembrete sonoro 1 dia antes.";textSize=15f}
        root.addView(title);root.addView(sub);root.addView(add,LinearLayout.LayoutParams(-1,64));root.addView(google,LinearLayout.LayoutParams(-1,64));root.addView(info);setContentView(root)
    }
    private fun newEvent(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,0,20,0)}
        val name=EditText(this).apply{hint="Nome do compromisso"}
        val date=EditText(this).apply{hint="Data (dd/MM/yyyy)";inputType=2}
        val time=EditText(this).apply{hint="Horário (HH:mm)";inputType=2}
        val place=EditText(this).apply{hint="Local (opcional)"}
        box.addView(name);box.addView(date);box.addView(time);box.addView(place)
        AlertDialog.Builder(this).setTitle("Novo compromisso").setView(box).setPositiveButton("Salvar"){_,_->save(name.text.toString(),date.text.toString(),time.text.toString(),place.text.toString())}.setNegativeButton("Cancelar",null).show()
    }
    private fun save(n:String,d:String,t:String,p:String){
        try{val start=SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.getDefault()).parse("$d $t")!!.time; val end=start+3600000
            val values=ContentValues().apply{put(CalendarContract.Events.DTSTART,start);put(CalendarContract.Events.DTEND,end);put(CalendarContract.Events.TITLE,n);put(CalendarContract.Events.EVENT_LOCATION,p);put(CalendarContract.Events.CALENDAR_ID,calendarId()) ;put(CalendarContract.Events.EVENT_TIMEZONE,TimeZone.getDefault().id)}
            val uri=contentResolver.insert(CalendarContract.Events.CONTENT_URI,values); if(uri!=null){ schedule(start,n); Toast.makeText(this,"Compromisso salvo! Lembrete: 1 dia antes.",Toast.LENGTH_LONG).show() }
        }catch(e:Exception){Toast.makeText(this,"Confira a data e o horário.",Toast.LENGTH_LONG).show()}
    }
    private fun calendarId():Long{ val c=contentResolver.query(CalendarContract.Calendars.CONTENT_URI,arrayOf(CalendarContract.Calendars._ID),"${CalendarContract.Calendars.VISIBLE}=1",null,"${CalendarContract.Calendars._ID} ASC"); c?.use{if(it.moveToFirst())return it.getLong(0)}; return 1 }
    private fun schedule(start:Long,n:String){ val at=start-24*60*60*1000; val am=getSystemService(ALARM_SERVICE) as AlarmManager; val i=Intent(this,ReminderReceiver::class.java).putExtra("name",n); val pi=PendingIntent.getBroadcast(this,(start%Int.MAX_VALUE).toInt(),i,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE); if(at>System.currentTimeMillis())am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi) }
}
