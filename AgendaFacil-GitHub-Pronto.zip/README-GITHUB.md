# Agenda Fácil — pronto para compilar no GitHub

Este projeto já contém um workflow do GitHub Actions para gerar automaticamente o APK.

## Como gerar o APK

1. Crie um repositório novo no GitHub, por exemplo `AgendaFacil`.
2. Envie **todos os arquivos e pastas deste projeto** para o repositório.
3. No GitHub, abra a aba **Actions**.
4. Selecione **Gerar APK - Agenda Fácil**.
5. Clique em **Run workflow**.
6. Aguarde a compilação terminar.
7. Abra a execução concluída e, em **Artifacts**, baixe `AgendaFacil-APK`.

O workflow usa Java 17 e executa `./gradlew assembleDebug`.
